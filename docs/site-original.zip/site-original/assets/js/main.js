const y=document.getElementById('year');if(y)y.textContent=new Date().getFullYear();
document.querySelectorAll('a[href^="#"]').forEach(a=>{a.addEventListener('click',e=>{const id=a.getAttribute('href');if(!id||id==='#')return;const el=document.querySelector(id);if(el){e.preventDefault();el.scrollIntoView({behavior:'smooth',block:'start'});}});});
const setLang=(lang)=>{document.body.setAttribute('data-lang',lang);document.getElementById('lang-en').setAttribute('aria-pressed', lang==='en');document.getElementById('lang-pt').setAttribute('aria-pressed', lang==='pt');localStorage.setItem('lang',lang);};
document.getElementById('lang-en').onclick=()=>setLang('en');
document.getElementById('lang-pt').onclick=()=>setLang('pt');
setLang(localStorage.getItem('lang')||'en');